#!/bin/bash
# 用模拟服务端运行 opencode 的一个剧本。
# 用法：OPENCODE_SRC=~/opencode ./run.sh <剧本名> "<提示词>"
# 例如：OPENCODE_SRC=~/opencode ./run.sh 01-read "读一下 hello.txt"
set -e
LAB=$(cd "$(dirname "$0")" && pwd)
NAME=$1; shift
: "${OPENCODE_SRC:?请把 OPENCODE_SRC 设为 opencode 仓库的路径}"
PORT=${PORT:-18082}
DEMO=$LAB/demo
LOG=$LAB/logs/$NAME.jsonl

# 演示项目：一个 git 仓库，里面有一个文件和一份 AGENTS.md
if [ ! -d "$DEMO" ]; then
  mkdir -p "$DEMO"
  echo "hello from the demo project" > "$DEMO/hello.txt"
  printf '# Demo\n\n用中文回答。\n' > "$DEMO/AGENTS.md"
  echo "API_KEY=demo-secret" > "$DEMO/.env"
  mkdir -p "$DEMO/docs"
  printf '# docs 目录\n\n这个目录下的文档用英文写。\n' > "$DEMO/docs/AGENTS.md"
  echo "release notes draft" > "$DEMO/docs/notes.txt"
  (cd "$DEMO" && git init -q && git add -A && git -c user.name=lab -c user.email=lab@example.com commit -qm init)
fi
sed "s#__PORT__#$PORT#" "$LAB/opencode.json" > "$DEMO/opencode.json"

# 压缩剧本用一个上下文很小的模型，让压缩更快触发
MODELS=$LAB/models.json
[[ "$NAME" == *compact* ]] && MODELS=$LAB/models-small.json

mkdir -p "$LAB/logs"
rm -f "$LOG"
DEMO_DIR=$DEMO python3 "$LAB/mock-anthropic.py" "$LAB/scenarios/$NAME.json" "$LOG" "$PORT" &
MOCK=$!
trap 'kill $MOCK 2>/dev/null' EXIT
sleep 1

# 数据、配置、缓存都放在实验目录里，不影响你自己的 opencode
cd "$DEMO"
env XDG_DATA_HOME="$LAB/.home/data" XDG_CONFIG_HOME="$LAB/.home/config" \
    XDG_CACHE_HOME="$LAB/.home/cache" XDG_STATE_HOME="$LAB/.home/state" \
    OPENCODE_MODELS_PATH="$MODELS" OPENCODE_DISABLE_MODELS_FETCH=1 \
  bun run --cwd "$OPENCODE_SRC/packages/opencode" src/index.ts run "$@" < /dev/null || true

echo
echo "请求日志：$LOG（用 python3 show.py $LOG 查看）"
