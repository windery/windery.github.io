#!/usr/bin/env python3
"""一个最小的 MCP 服务端（stdio 传输），只提供一个工具 now：返回当前时间。

MCP 的 stdio 传输就是一行一个 JSON-RPC 消息：从 stdin 读请求，往 stdout 写响应。
不依赖任何第三方库，方便看清协议本身。
"""
import json
import sys
from datetime import datetime

TOOLS = [{
    "name": "now",
    "description": "返回服务端所在机器的当前时间",
    "inputSchema": {
        "type": "object",
        "properties": {"format": {"type": "string", "description": "strftime 格式，默认 %Y-%m-%d %H:%M:%S"}},
    },
}]


def log(msg):
    # stdout 只能写协议消息，日志写到 stderr
    print(f"[mcp-time] {msg}", file=sys.stderr, flush=True)


def handle(req):
    method = req.get("method")
    params = req.get("params") or {}
    if method == "initialize":
        return {
            "protocolVersion": params.get("protocolVersion", "2025-06-18"),
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "mcp-time", "version": "0.1.0"},
            "instructions": "需要知道当前时间时，调用 now 工具。",
        }
    if method == "tools/list":
        return {"tools": TOOLS}
    if method == "tools/call":
        fmt = (params.get("arguments") or {}).get("format") or "%Y-%m-%d %H:%M:%S"
        return {"content": [{"type": "text", "text": datetime.now().strftime(fmt)}]}
    if method == "ping":
        return {}
    raise ValueError(f"不支持的方法：{method}")


for line in sys.stdin:
    if not line.strip():
        continue
    req = json.loads(line)
    log(f"收到 {req.get('method')}")
    if "id" not in req:  # 通知（比如 notifications/initialized）不需要回复
        continue
    try:
        resp = {"jsonrpc": "2.0", "id": req["id"], "result": handle(req)}
    except Exception as e:
        resp = {"jsonrpc": "2.0", "id": req["id"], "error": {"code": -32601, "message": str(e)}}
    print(json.dumps(resp, ensure_ascii=False), flush=True)
