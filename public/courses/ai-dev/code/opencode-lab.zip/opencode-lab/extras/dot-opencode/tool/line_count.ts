import { tool } from "@opencode-ai/plugin"

export default tool({
  description: "统计一个文本文件有多少行",
  args: {
    path: tool.schema.string().describe("文件的绝对路径"),
  },
  async execute(args) {
    const text = await Bun.file(args.path).text()
    return `${args.path} 共 ${text.split("\n").length - 1} 行`
  },
})
