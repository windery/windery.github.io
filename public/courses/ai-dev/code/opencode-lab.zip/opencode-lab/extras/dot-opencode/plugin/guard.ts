import type { Plugin } from "@opencode-ai/plugin"

export const Guard: Plugin = async () => ({
  "tool.execute.before": async (input, output) => {
    if (input.tool === "read" && String(output.args.filePath).endsWith(".env")) {
      throw new Error("guard 插件：不允许读取 .env")
    }
  },
  "tool.execute.after": async (input, output) => {
    console.error(`[guard] ${input.tool} 执行完毕，output 的字段：${Object.keys(output).join(", ")}`)
  },
})
