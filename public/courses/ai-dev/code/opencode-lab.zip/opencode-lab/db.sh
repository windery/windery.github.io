#!/bin/bash
# 查询实验用的 opencode 数据库（SQLite）。
# 用法：OPENCODE_SRC=~/opencode ./db.sh            # 列出最近一个会话的所有 part
#       OPENCODE_SRC=~/opencode ./db.sh "<SQL>"    # 执行任意查询
LAB=$(cd "$(dirname "$0")" && pwd)
: "${OPENCODE_SRC:?请把 OPENCODE_SRC 设为 opencode 仓库的路径}"
SQL=${1:-"select json_extract(m.data, '\$.role') as role,
       json_extract(p.data, '\$.type') as type,
       coalesce(json_extract(p.data, '\$.tool'), substr(json_extract(p.data, '\$.text'), 1, 30),
                json_extract(p.data, '\$.reason'), '') as detail
from part p join message m on p.message_id = m.id
where m.session_id = (select id from session where parent_id is null order by time_created desc limit 1)
order by p.id"}
env XDG_DATA_HOME="$LAB/.home/data" XDG_CONFIG_HOME="$LAB/.home/config" \
  bun run --cwd "$OPENCODE_SRC/packages/opencode" src/index.ts db "$SQL" < /dev/null
