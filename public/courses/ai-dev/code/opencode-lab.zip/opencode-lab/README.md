# opencode-lab

「Vibe Coding 与 Agent 原理」第五部分的实验：用一个模拟的 Anthropic API 服务端运行 opencode，不需要 API key，就能看到 opencode 发给模型的每一个请求。

## 需要

- Bun、Python 3、git
- opencode 源码，切到课程使用的版本并安装依赖：

```sh
git clone https://github.com/anomalyco/opencode.git ~/opencode
cd ~/opencode && git checkout 108b988a08227df45417f27905a4d6b27ad49b6d && bun install
```

## 运行

```sh
export OPENCODE_SRC=~/opencode
./run.sh 01-read "读一下 hello.txt"
python3 show.py logs/01-read.jsonl            # 查看请求摘要
python3 show.py logs/01-read.jsonl --system   # 连同完整的系统提示一起查看
```

查询 opencode 存下来的会话数据（SQLite）：

```sh
./db.sh                                                   # 最近一个会话的所有 part
./db.sh "select id, parent_id, title from session"        # 任意 SQL
```

第一次运行会在 `demo/` 下创建一个演示项目。opencode 的数据、配置和缓存都放在 `.home/` 下，不影响你自己安装的 opencode。

## 剧本

| 剧本 | 模型（模拟）做了什么 | 用来观察 |
| --- | --- | --- |
| `01-read` | 调用 read 读文件，然后回答 | 一次完整的 agent 循环；系统提示、工具列表、tool_result 的格式 |
| `02-deny` | 运行 `ls && rm hello.txt`，再运行 `ls \| wc -l` | 复合命令被拆开检查，`rm *` 的 deny 规则拒绝了整条命令 |
| `03-task` | 调用 task 派出 explore 子 agent | 子 agent 的系统提示和工具列表，结果如何返回给主 agent |
| `04-compact` | 一次工具调用后报告用了 27000 个输入 token | 超过上下文上限时的自动压缩：压缩请求和压缩后的历史 |
| `05-doom-loop` | 一次回复里三次调用完全相同的工具 | 死循环检测；非交互模式下权限请求被自动拒绝 |
| `06-env` | 读取 `.env` | 默认规则对 `.env` 是 ask；非交互模式下被自动拒绝，循环停止 |
| `07-nested` | 读取 `docs/notes.txt` | 读到子目录时，子目录里的 AGENTS.md 被附加到 tool_result 里 |
| `08-write` | 用 write 创建 `todo.md` | 每一步前后的快照，以及记录文件改动的 patch |

剧本是 `scenarios/` 下的 JSON 文件，可以照着格式写自己的剧本。模拟服务端把不带工具的请求（生成标题、压缩上下文）单独处理，不消耗剧本。
