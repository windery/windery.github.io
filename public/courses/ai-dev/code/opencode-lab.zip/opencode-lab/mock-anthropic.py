"""一个最小的 Anthropic Messages API 模拟服务端，用来观察 opencode 发出的请求。

用法：python3 mock-anthropic.py <剧本.json> <请求日志.jsonl> <端口>

- 带工具的请求（主 agent、子 agent）按剧本依次返回；剧本里的 __DEMO__ 会替换成演示项目的绝对路径。
- 不带工具的请求是 opencode 的辅助调用：生成标题，或者压缩上下文。分别返回固定的标题和摘要，不消耗剧本。
- 每个请求的路径、请求头和请求体都追加写入日志，供 show.py 查看。
"""
import json, os, sys, http.server

demo = os.environ.get("DEMO_DIR", "")
script = json.loads(open(sys.argv[1], encoding="utf-8").read().replace("__DEMO__", demo))
log, port = sys.argv[2], int(sys.argv[3])
state = {"next": 0}


def pick(body):
    if not body.get("tools"):
        if "context summarization agent" in json.dumps(body.get("system", "")):
            text = "## Objective\n- 查看目录内容\n\n## Work State\n### Completed\n- 已运行 ls"
        else:
            text = "演示会话"
        return {"content": [{"type": "text", "text": text}], "stop": "end_turn"}
    i = state["next"]
    state["next"] += 1
    if i < len(script):
        return script[i]
    return {"content": [{"type": "text", "text": "(剧本已用完)"}], "stop": "end_turn"}


def sse(step, model):
    usage = {"input_tokens": step.get("usage_input", 1000), "output_tokens": 1,
             "cache_read_input_tokens": 0, "cache_creation_input_tokens": 0}
    events = [{"type": "message_start", "message": {"id": "msg_mock", "type": "message", "role": "assistant",
               "model": model, "content": [], "stop_reason": None, "stop_sequence": None, "usage": usage}}]
    for idx, block in enumerate(step["content"]):
        if block["type"] == "text":
            events.append({"type": "content_block_start", "index": idx, "content_block": {"type": "text", "text": ""}})
            events.append({"type": "content_block_delta", "index": idx, "delta": {"type": "text_delta", "text": block["text"]}})
        else:
            events.append({"type": "content_block_start", "index": idx, "content_block":
                           {"type": "tool_use", "id": block["id"], "name": block["name"], "input": {}}})
            events.append({"type": "content_block_delta", "index": idx, "delta":
                           {"type": "input_json_delta", "partial_json": json.dumps(block["input"], ensure_ascii=False)}})
        events.append({"type": "content_block_stop", "index": idx})
    events.append({"type": "message_delta", "delta": {"stop_reason": step["stop"], "stop_sequence": None},
                   "usage": {"output_tokens": 50}})
    events.append({"type": "message_stop"})
    return "".join(f"event: {e['type']}\ndata: {json.dumps(e, ensure_ascii=False)}\n\n" for e in events).encode()


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["content-length"])))
        with open(log, "a", encoding="utf-8") as f:
            f.write(json.dumps({"path": self.path, "headers": dict(self.headers), "body": body}, ensure_ascii=False) + "\n")
        data = sse(pick(body), body.get("model"))
        self.send_response(200)
        self.send_header("content-type", "text/event-stream")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
