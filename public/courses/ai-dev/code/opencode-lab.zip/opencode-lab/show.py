"""把 mock-anthropic.py 记录的请求整理成可读的摘要。用法：python3 show.py <请求日志.jsonl> [--system]"""
import json, sys

full_system = "--system" in sys.argv
for n, line in enumerate(open(sys.argv[1], encoding="utf-8"), 1):
    body = json.loads(line)["body"]
    system = "\n".join(s["text"] for s in body.get("system", []))
    tools = [t["name"] for t in body.get("tools", [])]
    print(f"===== 请求 {n}：{len(body['messages'])} 条消息，工具 {tools or '无'}")
    print(f"system（{len(system)} 字符）：" + (system if full_system else system[:80].replace("\n", " ") + " ..."))
    for m in body["messages"]:
        content = m["content"] if isinstance(m["content"], list) else [{"type": "text", "text": m["content"]}]
        for c in content:
            value = c.get("text") or c.get("content") or c.get("input")
            mark = " [cache]" if c.get("cache_control") else ""
            print(f"  {m['role']:9} {c['type']:11}{mark} {json.dumps(value, ensure_ascii=False)[:200]}")
    print()
