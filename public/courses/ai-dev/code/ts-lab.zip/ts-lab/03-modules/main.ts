// 03：模块。运行：bun 03-modules/main.ts
import { Todo } from "./todo" // 拿到的是整个文件的命名空间对象

const item: Todo.Info = Todo.create("补测试") // 用法像 Java 的 Todo.create(...)
console.log(item)
