// opencode 的模块写法：文件里是平铺的导出，最后一行把整个文件作为一个命名空间再导出一次
export interface Info {
  content: string
  status: string
}

export const create = (content: string): Info => ({ content, status: "pending" })

export * as Todo from "./todo"
