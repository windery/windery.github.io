// 01：类型、联合类型与类型收窄。运行：bun 01-types.ts
export {}

// interface 描述对象的形状，类似 Java 的接口或 record，但只在编译期存在
interface Todo {
  content: string
  status: "pending" | "in_progress" | "completed" // 字符串字面量联合类型，代替 enum
  priority?: number // 可选字段，值可能是 undefined
}

// 可辨识联合（discriminated union）：每个成员都有一个 type 字段，值各不相同。
// 相当于 Java 的 sealed interface + 若干 record。
type Part =
  | { type: "text"; text: string }
  | { type: "tool"; tool: string; input: Record<string, unknown> }
  | { type: "step-finish"; reason: string; tokens: number }

function describe(part: Part): string {
  // switch 之后，TypeScript 知道每个 case 里 part 的具体类型（类型收窄）
  switch (part.type) {
    case "text":
      return `文本：${part.text}`
    case "tool":
      return `调用工具 ${part.tool}，参数 ${JSON.stringify(part.input)}`
    case "step-finish":
      return `一步结束，原因 ${part.reason}，用了 ${part.tokens} token`
  }
}

const parts: Part[] = [
  { type: "text", text: "我先读一下文件。" },
  { type: "tool", tool: "read", input: { filePath: "/tmp/a.txt" } },
  { type: "step-finish", reason: "tool-calls", tokens: 1200 },
]
parts.map(describe).forEach((line) => console.log(line))

// 用户自定义的类型守卫：返回值写成 `x is T`，filter 之后数组的类型就是 T[]
const tools = parts.filter((p): p is Extract<Part, { type: "tool" }> => p.type === "tool")
console.log("工具调用：", tools.map((t) => t.tool))

// ?. 和 ??：可选链和空值合并
const todo: Todo = { content: "写测试", status: "pending" }
console.log("优先级：", todo.priority ?? "未设置")
const last = parts.findLast((p) => p.type === "text")
console.log("最后一段文本：", last?.type === "text" ? last.text : "")

// 展开语法：复制并修改，相当于 record 的 with 或 builder 的 toBuilder()
const done = { ...todo, status: "completed" as const }
console.log(todo.status, "→", done.status)

// satisfies：检查值符合某个类型，但保留更精确的推断类型
const limits = { read: 2000, bytes: 50 * 1024 } satisfies Record<string, number>
console.log("read 默认行数：", limits.read)
