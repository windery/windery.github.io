# ts-lab

「Vibe Coding 与 Agent 原理」第 23 课的示例：读懂 opencode 源码需要的 TypeScript 和 Effect 写法。

```sh
bun install
bun 01-types.ts          # 类型、可辨识联合、类型收窄
bun 02-async.ts          # Promise、async/await、异步迭代、取消
bun 03-modules/main.ts   # 模块与 export * as
bun 04-effect.ts         # Effect：gen/yield*、服务与 Layer、pipe、Schema、Stream
bunx tsc -p .            # 类型检查
```

Effect 的版本固定为 4.0.0-beta.83，与 opencode 使用的版本一致。
