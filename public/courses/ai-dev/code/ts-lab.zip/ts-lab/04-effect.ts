// 04：读懂 opencode 需要的 Effect 写法。运行：bun 04-effect.ts
import { Context, Effect, Layer, Schedule, Schema, Stream } from "effect"

// ---------- 1. Effect 是“描述一段计算”的值，运行时才执行 ----------
// Effect.gen + yield* 读作：按顺序执行，yield* 相当于 await
const hello = Effect.gen(function* () {
  const name = yield* Effect.succeed("opencode")
  return `hello, ${name}`
})
console.log(await Effect.runPromise(hello))

// ---------- 2. 服务：接口 + 标识（Context.Service）+ 实现（Layer） ----------
// 相当于 Spring 里的：接口、@Bean 的类型、@Configuration 里的工厂方法
interface ClockShape {
  readonly now: () => Effect.Effect<Date>
}
class Clock extends Context.Service<Clock, ClockShape>()("@demo/Clock") {}

interface TodoShape {
  readonly add: (content: string) => Effect.Effect<string>
}
class Todo extends Context.Service<Todo, TodoShape>()("@demo/Todo") {}

const clockLayer = Layer.succeed(Clock, Clock.of({ now: () => Effect.succeed(new Date("2026-10-03T10:00:00Z")) }))

// Todo 的实现依赖 Clock：在 Layer.effect 里用 yield* 拿到依赖，相当于构造器注入
const todoLayer = Layer.effect(
  Todo,
  Effect.gen(function* () {
    const clock = yield* Clock
    // Effect.fn("名字") 定义一个带名字（用于追踪）的函数，函数体同样是 generator
    const add = Effect.fn("Todo.add")(function* (content: string) {
      const now = yield* clock.now()
      return `[${now.toISOString()}] ${content}`
    })
    return Todo.of({ add })
  }),
)

const program = Effect.gen(function* () {
  const todo = yield* Todo
  return yield* todo.add("补测试")
})
// 运行前要“提供”依赖，否则类型检查不通过
console.log(await Effect.runPromise(program.pipe(Effect.provide(todoLayer.pipe(Layer.provide(clockLayer))))))

// ---------- 3. pipe：重试、捕获错误、finally ----------
let attempts = 0
const flaky = Effect.gen(function* () {
  attempts++
  if (attempts < 3) return yield* Effect.fail(new Error(`第 ${attempts} 次调用失败：overloaded`))
  return "第 3 次成功"
})
const withRetry = flaky.pipe(
  Effect.retry(Schedule.recurs(5)), // 失败后最多再试 5 次
  Effect.catch((e) => Effect.succeed(`放弃：${e.message}`)), // 相当于 catch
  Effect.ensuring(Effect.sync(() => console.log("清理资源"))), // 相当于 finally
)
console.log(await Effect.runPromise(withRetry))

// ---------- 4. Schema：定义数据结构，同时得到类型和校验 ----------
const ReadParams = Schema.Struct({
  filePath: Schema.String,
  offset: Schema.optional(Schema.Number),
})
type ReadParams = Schema.Schema.Type<typeof ReadParams> // 从 Schema 推出 TypeScript 类型
const ok: ReadParams = await Effect.runPromise(Schema.decodeUnknownEffect(ReadParams)({ filePath: "/tmp/a.txt" }))
console.log("校验通过：", ok)
const bad = await Effect.runPromise(Effect.result(Schema.decodeUnknownEffect(ReadParams)({ offset: "10" })))
console.log("校验失败：", bad._tag)

// ---------- 5. Stream：一个事件一个事件地处理 ----------
type Ev = { type: "text-delta"; text: string } | { type: "finish"; reason: string }
const events: Ev[] = [
  { type: "text-delta", text: "读" },
  { type: "text-delta", text: "文件" },
  { type: "finish", reason: "tool-calls" },
]
let text = ""
await Effect.runPromise(
  Stream.fromIterable(events).pipe(
    Stream.tap((e) => Effect.sync(() => (e.type === "text-delta" ? (text += e.text) : console.log("finish:", e.reason)))),
    Stream.runDrain,
  ),
)
console.log("拼出的文本：", text)
