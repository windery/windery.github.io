// 02：Promise、async/await 与异步迭代。运行：bun 02-async.ts
export {} // 有 import 或 export 的文件才是模块；模块顶层可以 await，变量也不会和全局的冲突

// Promise 相当于 Java 的 CompletableFuture。async 函数总是返回 Promise。
async function readFile(path: string): Promise<string> {
  await Bun.sleep(50) // 模拟 IO
  return `${path} 的内容`
}

// 异步生成器：一边产生事件，一边让调用方消费，类似一个简化的响应式流。
// 模型的流式输出在 opencode 里就是这样被一个事件一个事件地处理的。
type ModelEvent = { type: "text-delta"; text: string } | { type: "finish"; reason: string }

async function* fakeModelStream(signal: AbortSignal): AsyncGenerator<ModelEvent> {
  for (const word of ["我", "先", "读", "一下", "文件"]) {
    if (signal.aborted) return
    await Bun.sleep(30)
    yield { type: "text-delta", text: word }
  }
  yield { type: "finish", reason: "stop" }
}

async function main() {
  // 并发执行，等全部完成，相当于 CompletableFuture.allOf
  const [a, b] = await Promise.all([readFile("a.txt"), readFile("b.txt")])
  console.log(a, "|", b)

  // AbortController 用来取消：用户按下 Esc 时，opencode 就是通过它中止模型请求和工具
  const controller = new AbortController()
  setTimeout(() => controller.abort(), 100)

  let text = ""
  for await (const event of fakeModelStream(controller.signal)) {
    if (event.type === "text-delta") text += event.text
    if (event.type === "finish") console.log("结束原因：", event.reason)
  }
  console.log("收到的文本：", text, controller.signal.aborted ? "（被取消）" : "")

  // try/catch 和 Java 一样；throw 可以抛出任何值，惯例是 Error 对象
  try {
    JSON.parse("{坏的 JSON")
  } catch (e) {
    console.log("解析失败：", e instanceof Error ? e.message : e)
  }
}

await main() // 模块顶层可以直接 await
