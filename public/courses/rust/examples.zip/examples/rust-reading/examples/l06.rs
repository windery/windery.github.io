fn main() {
    let a = String::from("rust");
    let b = a;
    let c = b.clone();
    let x = 7;
    let y = x;
    println!("{b} {c} {x} {y}");
}
