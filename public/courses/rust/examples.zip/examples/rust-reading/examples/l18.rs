mod model {
    pub struct User {
        name: String,
    }
    impl User {
        pub fn new(name: &str) -> Self {
            Self {
                name: name.to_owned(),
            }
        }
        pub fn name(&self) -> &str {
            &self.name
        }
    }
}
use crate::model::User;
fn main() {
    println!("{}", User::new("Lin").name());
}
