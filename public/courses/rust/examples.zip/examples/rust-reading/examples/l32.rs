struct UserId(u64);
fn show(id: UserId) {
    println!("{}", id.0);
}
fn main() {
    let large = 300_u16;
    println!("{} {}", large as u8, u8::try_from(large).is_err());
    show(UserId(7));
}
