struct Notice;
impl Drop for Notice {
    fn drop(&mut self) {
        println!("released");
    }
}
fn main() {
    let boxed = Box::new(7);
    println!("{}", *boxed);
    let notice = Notice;
    drop(notice);
    println!("after");
}
