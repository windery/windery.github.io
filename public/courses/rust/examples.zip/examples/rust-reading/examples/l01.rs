fn double(n: i32) -> i32 {
    n * 2
}
fn main() {
    let answer = double(21);
    println!("{answer}");
}
