fn main() {
    let values = vec![1, 2, 3, 4];
    let result: Vec<i32> = values
        .iter()
        .copied()
        .filter(|n| *n % 2 == 0)
        .map(|n| n * 10)
        .collect();
    println!("{:?} {}", result, values.len());
}
