fn choose<T>(first: T, second: T, use_first: bool) -> T {
    if use_first { first } else { second }
}
fn length<T, const N: usize>(_: &[T; N]) -> usize {
    N
}
fn main() {
    let word = choose(String::from("left"), String::from("right"), true);
    println!("{} {}", word, length(&[1, 2, 3]));
}
