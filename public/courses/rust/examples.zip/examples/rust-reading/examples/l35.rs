#[derive(Debug, PartialEq)]
struct Rule<'a> {
    name: &'a str,
    limit: u32,
}
fn parse_rule(line: &str) -> Result<Rule<'_>, &'static str> {
    let (name, raw) = line.split_once('=').ok_or("missing =")?;
    let name = name.trim();
    if name.is_empty() {
        return Err("empty name");
    }
    let limit = raw.trim().parse::<u32>().map_err(|_| "bad limit")?;
    Ok(Rule { name, limit })
}
fn main() {
    let input = String::from(
        "alpha=2
beta=5",
    );
    let rules: Result<Vec<_>, _> = input.lines().map(parse_rule).collect();
    match rules {
        Ok(items) => println!(
            "{} {}",
            items[0].name,
            items.iter().map(|r| r.limit).sum::<u32>()
        ),
        Err(error) => println!("{error}"),
    }
}
