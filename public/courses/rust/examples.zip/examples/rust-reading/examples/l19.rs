fn main() {
    let prefix = String::from("Hi");
    let greet = move |name: &str| format!("{prefix}, {name}");
    println!("{}", greet("Lin"));
    println!("{}", greet("Mei"));
}
