fn longer<'a>(left: &'a str, right: &'a str) -> &'a str {
    if left.len() >= right.len() {
        left
    } else {
        right
    }
}
fn main() {
    let left = String::from("rust");
    let right = String::from("go");
    let result = longer(&left, &right);
    println!("{result}");
}
