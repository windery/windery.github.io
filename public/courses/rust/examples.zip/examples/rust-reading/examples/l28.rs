struct User {
    name: String,
    score: u32,
}
fn main() {
    let user = User {
        name: String::from("Lin"),
        score: 7,
    };
    match &user {
        User {
            name,
            score: n @ 1..=9,
        } if name.len() > 2 => {
            println!("{name} {n}");
        }
        _ => println!("other"),
    }
    println!("{}", user.name);
}
