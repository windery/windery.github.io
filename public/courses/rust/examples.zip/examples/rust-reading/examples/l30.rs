fn main() {
    let value = 7_i32;
    let pointer: *const i32 = &value;
    // SAFETY: pointer 来自仍然有效且正确对齐的 i32 引用；只读且未发生冲突修改。
    let observed = unsafe { *pointer };
    println!("{observed}");
}
