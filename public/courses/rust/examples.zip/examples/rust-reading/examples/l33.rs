use std::{future::Future, pin::Pin};
fn identity(s: &str) -> &str {
    s
}
fn check<F>(f: F)
where
    F: for<'a> Fn(&'a str) -> &'a str,
{
    let local = String::from("borrowed");
    println!("{}", f(&local));
}
fn owned_future() -> Pin<Box<dyn Future<Output = u32> + Send + 'static>> {
    Box::pin(async { 42 })
}
fn main() {
    check(identity);
    drop(owned_future());
}
