use std::collections::HashMap;
fn main() {
    let mut counts = HashMap::new();
    for word in ["rust", "go", "rust"] {
        *counts.entry(word).or_insert(0) += 1;
    }
    println!("{:?}", counts.get("rust"));
    let values = vec![10, 20];
    println!("{:?}", values.get(9));
}
