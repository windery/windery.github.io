trait Sound {
    fn sound(&self) -> &'static str;
}
struct Cat;
struct Dog;
impl Sound for Cat {
    fn sound(&self) -> &'static str {
        "meow"
    }
}
impl Sound for Dog {
    fn sound(&self) -> &'static str {
        "woof"
    }
}
fn one() -> impl Sound {
    Cat
}
fn main() {
    let animals: Vec<Box<dyn Sound>> = vec![Box::new(Cat), Box::new(Dog)];
    for animal in animals {
        println!("{}", animal.sound());
    }
    println!("{}", one().sound());
}
