struct Once {
    value: Option<u32>,
}
impl Iterator for Once {
    type Item = u32;
    fn next(&mut self) -> Option<Self::Item> {
        self.value.take()
    }
}
fn total<I: Iterator<Item = u32>>(items: I) -> u32 {
    items.sum()
}
fn main() {
    println!("{}", total(Once { value: Some(9) }));
}
