fn main() {
    let nested = Some("12").map(|s| s.parse::<u32>().ok());
    let flat = Some("12").and_then(|s| s.parse::<u32>().ok());
    let values: Result<Vec<u32>, _> = ["1", "bad", "3"]
        .into_iter()
        .map(str::parse::<u32>)
        .collect();
    println!("{:?} {:?} {}", nested, flat, values.is_err());
}
