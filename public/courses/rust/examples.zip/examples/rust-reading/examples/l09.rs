fn main() {
    let text = String::from("你好");
    println!("{} {}", text.len(), text.chars().count());
    println!("{:?}", text.get(0..3));
    println!("{:?}", text.get(0..1));
}
