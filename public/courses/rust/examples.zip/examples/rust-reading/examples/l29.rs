macro_rules! list {
    ($($value:expr),* $(,)?) => { vec![$($value),*] };
}
#[derive(Debug, Clone)]
struct Item {
    count: u32,
}
fn main() {
    let values = list![2, 4, 6];
    let item = Item {
        count: values.len() as u32,
    };
    println!("{:?} {}", item.clone(), item.count);
}
