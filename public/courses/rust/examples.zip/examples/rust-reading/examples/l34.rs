fn main() {
    let mut text = String::from("read");
    let view = &text;
    println!("{view}");
    text.push('!');
    println!("{text}");
}
