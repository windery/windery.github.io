fn main() {
    let pair: (i32, bool) = (7, true);
    let numbers: [i32; 3] = [2, 4, 6];
    let (value, enabled) = pair;
    println!("{} {} {}", value, enabled, numbers[1]);
}
