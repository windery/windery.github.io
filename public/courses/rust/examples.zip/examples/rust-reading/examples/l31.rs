fn clamp_small(n: i32) -> i32 {
    n.clamp(0, 10)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn clamps_both_ends() {
        assert_eq!(clamp_small(-1), 0);
        assert_eq!(clamp_small(11), 10);
        assert_eq!(clamp_small(4), 4);
    }
}
fn main() {
    println!("{}", clamp_small(11));
}
