fn first_two(values: &[i32]) -> &[i32] {
    &values[..values.len().min(2)]
}
fn main() {
    let values = vec![10, 20, 30];
    let part = first_two(&values);
    println!("{:?}", part);
}
