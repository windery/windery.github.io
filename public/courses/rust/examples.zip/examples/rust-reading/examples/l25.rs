async fn answer() -> u32 {
    println!("running");
    42
}
async fn doubled() -> u32 {
    answer().await * 2
}
fn main() {
    let future = doubled();
    println!("created");
    drop(future);
}
