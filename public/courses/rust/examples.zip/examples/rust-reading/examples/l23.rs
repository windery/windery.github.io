use std::{cell::RefCell, rc::Rc};
fn main() {
    let shared = Rc::new(RefCell::new(1));
    let second = Rc::clone(&shared);
    let weak = Rc::downgrade(&shared);
    *second.borrow_mut() += 1;
    println!("{} {}", shared.borrow(), Rc::strong_count(&shared));
    drop(second);
    drop(shared);
    println!("{}", weak.upgrade().is_none());
}
