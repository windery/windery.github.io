struct Counter {
    value: u32,
}
impl Counter {
    fn new() -> Self {
        Self { value: 0 }
    }
    fn increment(&mut self) {
        self.value += 1;
    }
    fn value(&self) -> u32 {
        self.value
    }
    fn into_value(self) -> u32 {
        self.value
    }
}
fn main() {
    let mut counter = Counter::new();
    counter.increment();
    println!("{}", counter.value());
    println!("{}", counter.into_value());
}
