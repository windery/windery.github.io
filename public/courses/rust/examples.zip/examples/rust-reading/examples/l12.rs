fn label(value: Option<u32>) -> &'static str {
    let Some(n) = value else {
        return "missing";
    };
    match n {
        0 => "zero",
        1..=9 => "small",
        _ => "large",
    }
}
fn main() {
    println!("{} {}", label(None), label(Some(8)));
}
