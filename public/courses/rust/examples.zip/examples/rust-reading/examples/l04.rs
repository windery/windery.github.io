fn plus_one(n: i32) -> i32 {
    let increment = {
        let base = 0;
        base + 1
    };
    n + increment
}
fn main() {
    println!("{}", plus_one(4));
}
