fn main() {
    let mut total = 0;
    for n in 1..=3 {
        total += n;
    }
    let found = loop {
        if total > 5 {
            break total;
        }
        total += 1;
    };
    println!("{found}");
}
