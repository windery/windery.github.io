fn main() {
    let text = "12";
    let text: usize = text.len();
    let mut count = text;
    count += 1;
    println!("{count}");
}
