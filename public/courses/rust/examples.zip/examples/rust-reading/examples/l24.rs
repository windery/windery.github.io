use std::{
    sync::{Arc, Mutex},
    thread,
};
fn main() {
    let value = Arc::new(Mutex::new(0));
    let other = Arc::clone(&value);
    let handle = thread::spawn(move || {
        let mut guard = other.lock().expect("lock poisoned");
        *guard += 1;
    });
    handle.join().expect("thread panicked");
    println!("{}", *value.lock().expect("lock poisoned"));
}
