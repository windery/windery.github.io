enum Status {
    Offline,
    Online { users: usize },
}
fn user_count(status: Status) -> Option<usize> {
    match status {
        Status::Offline => None,
        Status::Online { users } => Some(users),
    }
}
fn main() {
    println!("{:?}", user_count(Status::Online { users: 3 }));
    println!("{:?}", user_count(Status::Offline));
}
