trait Named {
    fn name(&self) -> &str;
}
struct User {
    name: String,
}
impl Named for User {
    fn name(&self) -> &str {
        &self.name
    }
}
fn show<T>(value: &T)
where
    T: Named,
{
    println!("{}", value.name());
}
fn main() {
    show(&User {
        name: String::from("Lin"),
    });
}
