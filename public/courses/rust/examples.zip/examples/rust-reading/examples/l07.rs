fn append_mark(text: &mut String) {
    text.push('!');
}
fn main() {
    let mut name = String::from("Rust");
    let view = &name;
    println!("{view}");
    append_mark(&mut name);
    println!("{name}");
}
