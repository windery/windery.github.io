fn parse_port(text: &str) -> Result<u16, std::num::ParseIntError> {
    let value = text.parse::<u16>()?;
    Ok(value)
}
fn main() {
    println!("{:?}", parse_port("8080"));
    println!("{}", parse_port("oops").is_err());
}
