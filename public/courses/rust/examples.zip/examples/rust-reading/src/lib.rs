//! 综合阅读练习：返回的名称借自输入，解析错误作为值返回。
//!
//! ```
//! let rule = rust_reading::parse_rule("alpha = 2").unwrap();
//! assert_eq!(rule.name, "alpha");
//! assert_eq!(rule.limit, 2);
//! ```

#[derive(Debug, PartialEq)]
pub struct Rule<'a> {
    pub name: &'a str,
    pub limit: u32,
}

/// 解析一行 `name=limit`。名称会 trim，limit 必须是有效 u32。
pub fn parse_rule(line: &str) -> Result<Rule<'_>, &'static str> {
    let (name, raw) = line.split_once('=').ok_or("missing =")?;
    let name = name.trim();
    if name.is_empty() {
        return Err("empty name");
    }
    let limit = raw.trim().parse::<u32>().map_err(|_| "bad limit")?;
    Ok(Rule { name, limit })
}

/// 任意一行失败就返回错误；不返回部分成功结果。空输入得到空列表。
pub fn parse_rules(input: &str) -> Result<Vec<Rule<'_>>, &'static str> {
    input.lines().map(parse_rule).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn trims_name_and_limit() {
        assert_eq!(
            parse_rule(" alpha = 2 "),
            Ok(Rule {
                name: "alpha",
                limit: 2
            })
        );
    }
    #[test]
    fn supports_unicode_names_and_zero() {
        assert_eq!(
            parse_rule("中文=0"),
            Ok(Rule {
                name: "中文",
                limit: 0
            })
        );
    }
    #[test]
    fn rejects_missing_separator() {
        assert_eq!(parse_rule("alpha"), Err("missing ="));
    }
    #[test]
    fn rejects_empty_name() {
        assert_eq!(parse_rule(" =2"), Err("empty name"));
    }
    #[test]
    fn rejects_bad_limit_inputs() {
        for line in ["a=", "a=-1", "a=3.5", "a=oops", "a=2=3", "a=4294967296"] {
            assert_eq!(parse_rule(line), Err("bad limit"), "{line}");
        }
    }
    #[test]
    fn supports_full_u32_range() {
        assert_eq!(parse_rule("max=4294967295").unwrap().limit, u32::MAX);
    }
    #[test]
    fn empty_input_is_empty_list() {
        assert_eq!(parse_rules(""), Ok(vec![]));
    }
    #[test]
    fn trailing_newline_is_not_extra_rule() {
        assert_eq!(parse_rules("a=1\nb=2\n").unwrap().len(), 2);
    }
    #[test]
    fn empty_middle_line_is_error() {
        assert_eq!(parse_rules("a=1\n\nb=2"), Err("missing ="));
    }
    #[test]
    fn does_not_keep_partial_success() {
        assert_eq!(parse_rules("a=1\nb=bad\nc=3"), Err("bad limit"));
    }
}
